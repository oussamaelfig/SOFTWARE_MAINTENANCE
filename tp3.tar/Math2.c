
#include <math.h>

#include "Math2.h"


double log2( double a_x ) {
  return log( a_x ) / log( 2.0 );
}
